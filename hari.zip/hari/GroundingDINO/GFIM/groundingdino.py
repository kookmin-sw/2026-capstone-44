# ------------------------------------------------------------------------
# Grounding DINO
# url: https://github.com/IDEA-Research/GroundingDINO
# Copyright (c) 2023 IDEA. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
# Conditional DETR model and criterion classes.
# Copyright (c) 2021 Microsoft. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
# Modified from DETR (https://github.com/facebookresearch/detr)
# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
# ------------------------------------------------------------------------
# Modified from Deformable DETR (https://github.com/fundamentalvision/Deformable-DETR)
# Copyright (c) 2020 SenseTime. All Rights Reserved.
# ------------------------------------------------------------------------
import copy
from typing import List

import torch
import torch.nn.functional as F
from torch import nn
from torchvision.ops.boxes import nms
from transformers import AutoTokenizer, BertModel, BertTokenizer, RobertaModel, RobertaTokenizerFast    # text encoder

from groundingdino.util import box_ops, get_tokenlizer
from groundingdino.util.misc import (
    NestedTensor,
    accuracy,
    get_world_size,
    interpolate,    # feature map 해상도 맞추기
    inverse_sigmoid,    #  reference point를 iterative 하게 보정할 때 사용
    is_dist_avail_and_initialized,
    nested_tensor_from_tensor_list,   # 서로 다른 크기의 이미지를 하나의 배치로 묶을 때, tensor + mask 구조를 쓰기 위한 wrapper 타입
)
# 추론/디버깅/시각화용
from groundingdino.util.utils import get_phrases_from_posmap
from groundingdino.util.visualizer import COCOVisualizer
from groundingdino.util.vl_utils import create_positive_map_from_span

from ..registry import MODULE_BUILD_FUNCS
from .backbone import build_backbone
from .bertwarper import (
    BertModelWarper,
    generate_masks_with_special_tokens,
    generate_masks_with_special_tokens_and_transfer_map,
)
from .transformer import build_transformer
from .utils import MLP, ContrastiveEmbed, sigmoid_focal_loss    # ContrastiveEmbed: decoder query feature와 token embedding 간 유사도 계산, sigmoid_focal_loss: class 불균형 문제 해결


class GroundingDINO(nn.Module):
    """This is the Cross-Attention Detector module that performs object detection"""

    def __init__(
        self,
        backbone,
        transformer,
        num_queries,
        aux_loss=False,
        iter_update=False,
        query_dim=2,
        num_feature_levels=1,
        nheads=8,
        # two stage
        two_stage_type="no",  # ['no', 'standard']
        dec_pred_bbox_embed_share=True,     # 모든 decoder layer에서 동일한 bbox prediction head 사용(가중치 공유)
        two_stage_class_embed_share=True,   # encoder, decoder 모두 동일한 class prediction head 사용(가중치 공유)
        two_stage_bbox_embed_share=True,    # encoder, decoder 모두 동일한 bbox prediction head 사용(가중치 공유)
        num_patterns=0,
        dn_number=100,
        dn_box_noise_scale=0.4,
        dn_label_noise_ratio=0.5,
        dn_labelbook_size=100,          
        text_encoder_type="bert-base-uncased",
        sub_sentence_present=True,
        max_text_len=256,
    ):
        """Initializes the model.
        Parameters:
            backbone: torch module of the backbone to be used. See backbone.py
            transformer: torch module of the transformer architecture. See transformer.py
            num_queries: number of object queries, ie detection slot. This is the maximal number of objects
                         Conditional DETR can detect in a single image. For COCO, we recommend 100 queries.
            aux_loss: True if auxiliary decoding losses (loss at each decoder layer) are to be used.
        """
        super().__init__()
        self.num_queries = num_queries
        self.transformer = transformer
        self.hidden_dim = hidden_dim = transformer.d_model
        self.num_feature_levels = num_feature_levels
        self.nheads = nheads
        self.max_text_len = 256    
        self.sub_sentence_present = sub_sentence_present

        # setting query dim
        self.query_dim = query_dim  
        assert query_dim == 4

        # for dn training
        self.num_patterns = num_patterns   
        self.dn_number = dn_number
        self.dn_box_noise_scale = dn_box_noise_scale
        self.dn_label_noise_ratio = dn_label_noise_ratio
        self.dn_labelbook_size = dn_labelbook_size       # noise 추가할 때 사용하는 label 어휘집 크기: text 기반이라 사용 x

        # bert
        self.tokenizer = get_tokenlizer.get_tokenlizer(text_encoder_type)           # text tokenizer 생성
        self.bert = get_tokenlizer.get_pretrained_language_model(text_encoder_type)    # bert/roberta model 로드
        self.bert.pooler.dense.weight.requires_grad_(False)         # pooler: BERT의 [CLS] 토큰을 문장 representation으로 변환하는 layer. 학습 안 시킴
        self.bert.pooler.dense.bias.requires_grad_(False)           # bias도 학습 안 시킴
        self.bert = BertModelWarper(bert_model=self.bert)           # BertModelWarper: BERT 모델을 감싸서 (sub-sentence attention mask같은) 특수 토큰 처리 기능 추가 

        self.feat_map = nn.Linear(self.bert.config.hidden_size, self.hidden_dim, bias=True)  # hidden_size: BERT의 출력 차원(768), hidden_dim: 축소된 차원(256)
        nn.init.constant_(self.feat_map.bias.data, 0)  # bias를 0으로 초기화
        nn.init.xavier_uniform_(self.feat_map.weight.data)  # weight를 Xavier 초기화 (입력/출력 차원을 고려해서 적절한 범위로)
        # freeze

        # special tokens
        self.specical_tokens = self.tokenizer.convert_tokens_to_ids(["[CLS]", "[SEP]", ".", "?"])

        # prepare input projection layers
        if num_feature_levels > 1:  # multi-scale feature 사용할 때
            num_backbone_outs = len(backbone.num_channels) # level 수
            input_proj_list = []    # 각 level별 input proj이 저장됨
            for _ in range(num_backbone_outs):
                in_channels = backbone.num_channels[_] # 각 level별 채널 수
                input_proj_list.append(
                    nn.Sequential(                 # 1x1 conv + group norm 순차적으로 적용
                        nn.Conv2d(in_channels, hidden_dim, kernel_size=1),      # H*W는 유지하는 이유: Deformable att으로 sampling p만 사용하기 때문에 상관x
                        nn.GroupNorm(32, hidden_dim),
                    )
                )
            for _ in range(num_feature_levels - num_backbone_outs): # backbone feature map 개수보다 더 많은 feature level을 쓰고 싶을 때, 추가 레벨을 만들어 주는 부분
                input_proj_list.append(
                    nn.Sequential(
                        nn.Conv2d(in_channels, hidden_dim, kernel_size=3, stride=2, padding=1),
                        nn.GroupNorm(32, hidden_dim),
                    )
                )
                in_channels = hidden_dim
            self.input_proj = nn.ModuleList(input_proj_list)    # Pytorch가 인식할 수 있도록 
        else:      # 1개의 feature level만 사용할 때
            assert two_stage_type == "no", "two_stage_type should be no if num_feature_levels=1 !!!" # two_stage 쓰지 않음
            self.input_proj = nn.ModuleList( 
                [
                    nn.Sequential(
                        nn.Conv2d(backbone.num_channels[-1], hidden_dim, kernel_size=1),
                        nn.GroupNorm(32, hidden_dim),
                    )
                ]
            )

        self.backbone = backbone
        self.aux_loss = aux_loss
        self.box_pred_damping = box_pred_damping = None  

        self.iter_update = iter_update
        assert iter_update, "Why not iter_update?"

        # prepare pred layers
        self.dec_pred_bbox_embed_share = dec_pred_bbox_embed_share
        # prepare class & box embed
        _class_embed = ContrastiveEmbed()   # feature와 token embedding 간 유사도 계산

        _bbox_embed = MLP(hidden_dim, hidden_dim, 4, 3)     # 4: output 차원 offset(x, y, w, h), 3: 레이어 개수
        nn.init.constant_(_bbox_embed.layers[-1].weight.data, 0) 
        nn.init.constant_(_bbox_embed.layers[-1].bias.data, 0) 

        if dec_pred_bbox_embed_share:       # 모든 bbox prediction head가 동일한 MLP 사용(가중치 공유)
            box_embed_layerlist = [_bbox_embed for i in range(transformer.num_decoder_layers)]  # decoder 레이어 개수만큼 bbox prediction 필요
        else:
            box_embed_layerlist = [
                copy.deepcopy(_bbox_embed) for i in range(transformer.num_decoder_layers)
            ]
        class_embed_layerlist = [_class_embed for i in range(transformer.num_decoder_layers)]  # decoder 레이어 개수만큼 class prediction 필요
        self.bbox_embed = nn.ModuleList(box_embed_layerlist)    # 파이썬 리스트를 nn.ModuleList로 감싸 모델의 파라미터로 인식되도록 함
        self.class_embed = nn.ModuleList(class_embed_layerlist)
        self.transformer.decoder.bbox_embed = self.bbox_embed   # decoder가 매 레이어 통과할 때마다 내부에서 직접 bbox/class 예측하도록 decoder 객체 안에 head 추가
        self.transformer.decoder.class_embed = self.class_embed

        # two stage
        self.two_stage_type = two_stage_type
        assert two_stage_type in ["no", "standard"], "unknown param {} of two_stage_type".format(
            two_stage_type
        )
        if two_stage_type != "no":  # Language-guide Query Selection
            if two_stage_bbox_embed_share:  # encoder bbox head
                assert dec_pred_bbox_embed_share
                self.transformer.enc_out_bbox_embed = _bbox_embed
            else:
                self.transformer.enc_out_bbox_embed = copy.deepcopy(_bbox_embed)

            if two_stage_class_embed_share:  # encoder class head
                assert dec_pred_bbox_embed_share
                self.transformer.enc_out_class_embed = _class_embed
            else:
                self.transformer.enc_out_class_embed = copy.deepcopy(_class_embed)

            self.refpoint_embed = None  # two-stage면 encoder output이 reference point 역할을 하니까 따로 embedding 필요 없음 -> 초기 예측 box로 사용
        self._reset_parameters()

    def _reset_parameters(self):
        # init input_proj
        for proj in self.input_proj:
            nn.init.xavier_uniform_(proj[0].weight, gain=1)
            nn.init.constant_(proj[0].bias, 0)

    def set_image_tensor(self, samples: NestedTensor):
        if isinstance(samples, (list, torch.Tensor)):
            samples = nested_tensor_from_tensor_list(samples)
        self.features, self.poss = self.backbone(samples)

    def unset_image_tensor(self):
        if hasattr(self, 'features'):
            del self.features
        if hasattr(self,'poss'):
            del self.poss 

    def set_image_features(self, features , poss):
        self.features = features
        self.poss = poss

    def init_ref_points(self, use_num_queries):
        self.refpoint_embed = nn.Embedding(use_num_queries, self.query_dim)


#### <Forward>
    def forward(self, samples: NestedTensor, targets: List = None, **kw):
        """The forward expects a NestedTensor, which consists of:
           - samples.tensor: batched images, of shape [batch_size x 3 x H x W]
           - samples.mask: a binary mask of shape [batch_size x H x W], containing 1 on padded pixels

        It returns a dict with the following elements:
           - "pred_logits": the classification logits (including no-object) for all queries.
                            Shape= [batch_size x num_queries x num_classes]
           - "pred_boxes": The normalized boxes coordinates for all queries, represented as
                           (center_x, center_y, width, height). These values are normalized in [0, 1],
                           relative to the size of each individual image (disregarding possible padding).
                           See PostProcess for information on how to retrieve the unnormalized bounding box.
           - "aux_outputs": Optional, only returned when auxilary losses are activated. It is a list of
                            dictionnaries containing the two above keys for each decoder layer.
        """
        # text prompt 가져오는 방법 2가지
        if targets is None: # 추론시: caption 직접 넣기
            captions = kw["captions"]
        else: # 학습시: targets list에서 caption 가져오기
            captions = [t["caption"] for t in targets]

        # 1단계: 텍스트 처리
        tokenized = self.tokenizer(captions, padding="longest", return_tensors="pt").to(    # text를 token ID로 변환, padding: batch 내 가장 긴 text 길이에 맞춤, PyTorch 텐서로 반환
            samples.device  # .to(samples.device): 이미지랑 같은 GPU에 올림
        )
        # tokenized된 text, 특수 token 리스트, tokenizer를 입력받아 attention mask, ids, cate 반환하는 함수
        (  
            text_self_attention_masks,  # Sub-sentence level: [CLS], [SEP], ., ? 같은 특수 토큰 구간별로 서로 다른 구간끼리는 보지 못하게 하는 마스크
            position_ids,   # 각 token의 위치 index
            cate_to_token_mask_list,    # category(단어)가 어떤 token에 해당하는지 나타내는 마스크 리스트
        ) = generate_masks_with_special_tokens_and_transfer_map( 
            tokenized, self.specical_tokens, self.tokenizer
        )

        if text_self_attention_masks.shape[1] > self.max_text_len:  # text가 256보다 길면 잘라냄
            text_self_attention_masks = text_self_attention_masks[  # (bs, seq_len, seq_len) → (bs, 256, 256)
                :, : self.max_text_len, : self.max_text_len        
            ]
            position_ids = position_ids[:, : self.max_text_len]     # (bs, seq_len) → (bs, 256)
            tokenized["input_ids"] = tokenized["input_ids"][:, : self.max_text_len]     # self.tokenizer(captions, ...)가 자동으로 만들어서 넣어 주는 키들
            tokenized["attention_mask"] = tokenized["attention_mask"][:, : self.max_text_len]
            tokenized["token_type_ids"] = tokenized["token_type_ids"][:, : self.max_text_len]

        # extract text embeddings
        if self.sub_sentence_present:   # sub-sentence면 
            tokenized_for_encoder = {k: v for k, v in tokenized.items() if k != "attention_mask"}   # tokenized 딕셔너리를 k,v 쌍으로 순회하며 attention_mask만 제외하고 복사
            tokenized_for_encoder["attention_mask"] = text_self_attention_masks     # 딕셔너리에 k,v 쌍 추가
            tokenized_for_encoder["position_ids"] = position_ids    # 딕셔너리에 k,v 쌍 추가
        else:
            # import ipdb; ipdb.set_trace()
            tokenized_for_encoder = tokenized

        bert_output = self.bert(**tokenized_for_encoder)  # bs, 195, 768 (bert에 방금 만든 딕셔너리 넣기)

        encoded_text = self.feat_map(bert_output["last_hidden_state"])  # bert 마지막 레이어 출력: bs, 195, d_model(256) 차원 축소
        text_token_mask = tokenized.attention_mask.bool()  # bs, 195 
        # text_token_mask: True for nomask, False for mask
        # text_self_attention_masks: True for nomask, False for mask

        # 길이 제한: BERT 통과 후 혹시 길이가 바뀌었을 경우를 대비한 안전장치
        if encoded_text.shape[1] > self.max_text_len:
            encoded_text = encoded_text[:, : self.max_text_len, :]
            text_token_mask = text_token_mask[:, : self.max_text_len]
            position_ids = position_ids[:, : self.max_text_len]
            text_self_attention_masks = text_self_attention_masks[
                :, : self.max_text_len, : self.max_text_len
            ]

        # text_dict로 묶기: 이후 transformer에 text 정보 넘길 때 딕셔너리 하나로 묶어서 전달하기 위함
        text_dict = {
            "encoded_text": encoded_text,  # bs, 195, d_model
            "text_token_mask": text_token_mask,  # bs, 195
            "position_ids": position_ids,  # bs, 195
            "text_self_attention_masks": text_self_attention_masks,  # bs, 195,195
        }

        # import ipdb; ipdb.set_trace()
        if isinstance(samples, (list, torch.Tensor)):       # samples가 리스트나 일반 텐서로 들어오면 NestedTensor로 변환
            samples = nested_tensor_from_tensor_list(samples)
        if not hasattr(self, 'features') or not hasattr(self, 'poss'):  # set_image_tensor를 미리 호출했으면 backbone 재실행 안 함. 없으면 지금 backbone 통과시켜서 feature 추출
            self.set_image_tensor(samples)

        # 2단계: 이미지 처리
        srcs = []   # input_proj 통과한 feature들을 모아두는 빈 리스트  
        masks = []  # batch 안 이미지들 크기 제각각. tensor로 묶기 위해 패딩. 패딩 위치 알려줘서 att 제외
        for l, feat in enumerate(self.features):    # l: 몇 번째 레벨인지 idx, feat: 각 레벨의 NestedTensor
            src, mask = feat.decompose()    # NestedTensor를 src(이미지 feature)와 mask(패딩 위치)로 분리
            srcs.append(self.input_proj[l](src))
            masks.append(mask)
            assert mask is not None
        if self.num_feature_levels > len(srcs):     # backbone이 뽑은 것보다 더 많은 feature level 필요할 때 추가 생성
            _len_srcs = len(srcs)
            for l in range(_len_srcs, self.num_feature_levels):
                if l == _len_srcs:
                    src = self.input_proj[l](self.features[-1].tensors)
                else:
                    src = self.input_proj[l](srcs[-1])
                m = samples.mask
                mask = F.interpolate(m[None].float(), size=src.shape[-2:]).to(torch.bool)[0]
                pos_l = self.backbone[1](NestedTensor(src, mask)).to(src.dtype)
                srcs.append(src)
                masks.append(mask)
                self.poss.append(pos_l)

        # DN 비활성화
        input_query_bbox = input_query_label = attn_mask = dn_meta = None      
        # 3단계: Transformer 호출 
        hs, reference, hs_enc, ref_enc, init_box_proposal = self.transformer(   # 반환값: hiddenstate dec 출력, dec ref point, enc 출력, enc ref point, sigmoid 통과 전 박스(loss 계산시 사용. 현재는 사용 x)
            srcs, masks, input_query_bbox, self.poss, input_query_label, attn_mask, text_dict # multi-scale feat, padding mask, positional encoding, text embedding
        )

        # 4단계: 예측 Head (decoder 각 레이어마다 bbox offset 예측 및 ref point 업데이트)
        outputs_coord_list = []
        for dec_lid, (layer_ref_sig, layer_bbox_embed, layer_hs) in enumerate(   # dec_lid: 몇 번째 레이어인지 idx, layer_ref_sig: 현재 레이어의 reference point (sigmoid된 좌표), layer_bbox_embed: 현재 레이어의 MLP, layer_hs: 현재 레이어의 query feature
            zip(reference[:-1], self.bbox_embed, hs)        #  [: -1]: 마지막 레이어 제외
        ):
            layer_delta_unsig = layer_bbox_embed(layer_hs)  # 현재 레이어의 query feature를 MLP에 통과시켜 bbox embed 출력
            layer_outputs_unsig = layer_delta_unsig + inverse_sigmoid(layer_ref_sig)  # offset + sig 전 reference point
            layer_outputs_unsig = layer_outputs_unsig.sigmoid()     # sigmoid 통과
            outputs_coord_list.append(layer_outputs_unsig)          # bbox 예측 결과 리스트
        outputs_coord_list = torch.stack(outputs_coord_list)        # bbox 예측 결과 텐서

        outputs_class = torch.stack(                                # class 예측 결과 텐서
            [
                layer_cls_embed(layer_hs, text_dict)        # 현재 레이어의 query feature와 text embedding을 입력받아 유사도 계산
                for layer_cls_embed, layer_hs in zip(self.class_embed, hs)
            ]
        )
        out = {"pred_logits": outputs_class[-1], "pred_boxes": outputs_coord_list[-1]}  # 마지막 레이어의 class 예측 결과, 마지막 레이어의 bbox 예측 결과

        # aux loss: 각 decoder layer의 예측을 함께 반환 (학습 시 모든 layer에 loss 부과)
        if self.aux_loss:
            out['aux_outputs'] = self._set_aux_loss(outputs_class, outputs_coord_list)

        # for encoder output
        if hs_enc is not None:
            # prepare intermediate outputs
            interm_coord = ref_enc[-1]
            interm_class = self.transformer.enc_out_class_embed(hs_enc[-1], text_dict)
            out['interm_outputs'] = {'pred_logits': interm_class, 'pred_boxes': interm_coord}
            out['interm_outputs_for_matching_pre'] = {'pred_logits': interm_class, 'pred_boxes': init_box_proposal}
        unset_image_tensor = kw.get('unset_image_tensor', True)
        if unset_image_tensor:
            self.unset_image_tensor() ## If necessary
        return out

    @torch.jit.unused
    def _set_aux_loss(self, outputs_class, outputs_coord):
        # this is a workaround to make torchscript happy, as torchscript
        # doesn't support dictionary with non-homogeneous values, such
        # as a dict having both a Tensor and a list.
        return [
            {"pred_logits": a, "pred_boxes": b}
            for a, b in zip(outputs_class[:-1], outputs_coord[:-1])
        ]

# @: 데코레이터, 함수 등록해두기
@MODULE_BUILD_FUNCS.registe_with_name(module_name="groundingdino")
def build_groundingdino(args):

    backbone = build_backbone(args)
    transformer = build_transformer(args)

    dn_labelbook_size = args.dn_labelbook_size
    dec_pred_bbox_embed_share = args.dec_pred_bbox_embed_share
    sub_sentence_present = args.sub_sentence_present

    model = GroundingDINO(
        backbone,
        transformer,
        num_queries=args.num_queries,
        aux_loss=True,
        iter_update=True,
        query_dim=4,
        num_feature_levels=args.num_feature_levels,
        nheads=args.nheads,
        dec_pred_bbox_embed_share=dec_pred_bbox_embed_share,
        two_stage_type=args.two_stage_type,
        two_stage_bbox_embed_share=args.two_stage_bbox_embed_share,
        two_stage_class_embed_share=args.two_stage_class_embed_share,
        num_patterns=args.num_patterns,
        dn_number=0,
        dn_box_noise_scale=args.dn_box_noise_scale,
        dn_label_noise_ratio=args.dn_label_noise_ratio,
        dn_labelbook_size=dn_labelbook_size,
        text_encoder_type=args.text_encoder_type,
        sub_sentence_present=sub_sentence_present,
        max_text_len=args.max_text_len,
    )

    return model

